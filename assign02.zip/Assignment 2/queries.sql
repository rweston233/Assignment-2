-- #1 A query to list all persons with family relationships using joins between person, family and relationship
SELECT concat(P.lastName, ', ', P.firstName) as 'Name', fa.relationFam as 'Relation' , r.connection 
FROM Person P 
inner join family fa on P.idPerson = fa.idPerson
inner join relationship r on P.idPerson = r.idRelationship;

-- #2 A query to list all persons with friendship relationships using joins between person, friend and relationship
SELECT concat(P.lastName, ', ', P.firstName) as 'Name', fr.relationFri as 'Relation' , r.connection 
FROM Person P 
inner join friend fr on P.idPerson = fr.idPerson
inner join relationship r on P.idPerson = r.idRelationship;

-- #3 A query to list all person, with or without a relationship of any kind, and any family relationships (hint: left join)
SELECT concat(P.lastName, ', ', P.firstName) as 'Name', fa.relationFam as 'Relation' 
FROM Person P 
LEFT JOIN family fa
ON P.idPerson = fa.idRelationship;


-- xc work 
