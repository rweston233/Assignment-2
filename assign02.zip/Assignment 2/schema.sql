-- person table created first 
CREATE TABLE IF NOT EXISTS `wedding`.`Person` (
  `idPerson` INT NOT NULL AUTO_INCREMENT,
  `firstName` VARCHAR(45) NOT NULL,
  `lastName` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idPerson`))
ENGINE = InnoDB;

-- relationship table created next
CREATE TABLE IF NOT EXISTS `wedding`.`relationship` (
  `connection` VARCHAR(45) NOT NULL,
  `idRelationship` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idRelationship`))
ENGINE = InnoDB;

-- friend table 
CREATE TABLE IF NOT EXISTS `wedding`.`friend` (
  `relationFri` VARCHAR(45) NOT NULL,
  `idPerson` INT NOT NULL,
  `idRelationship` INT NOT NULL,
  PRIMARY KEY (`idPerson`, `idRelationship`),
  INDEX `fk_friend_relationship1_idx` (`idRelationship` ASC) VISIBLE,
  CONSTRAINT `fk_friend_Person`
    FOREIGN KEY (`idPerson`)
    REFERENCES `wedding`.`Person` (`idPerson`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_friend_relationship1`
    FOREIGN KEY (`idRelationship`)
    REFERENCES `wedding`.`relationship` (`idRelationship`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- family table
CREATE TABLE IF NOT EXISTS `wedding`.`family` (
  `relationFam` VARCHAR(45) NOT NULL,
  `idPerson` INT NOT NULL,
  `idRelationship` INT NOT NULL,
  PRIMARY KEY (`idPerson`, `idRelationship`),
  INDEX `fk_family_relationship1_idx` (`idRelationship` ASC) VISIBLE,
  CONSTRAINT `fk_family_Person1`
    FOREIGN KEY (`idPerson`)
    REFERENCES `wedding`.`Person` (`idPerson`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_family_relationship1`
    FOREIGN KEY (`idRelationship`)
    REFERENCES `wedding`.`relationship` (`idRelationship`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;