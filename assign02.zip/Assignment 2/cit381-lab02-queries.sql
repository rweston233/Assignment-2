-- #1 (13 rows): Employees in offices not in the US using offices.country
-- # Number, Employee, Office
SELECT 
e1.employeeNumber as '# Number',
concat(e1.lastName, ', ', e1.firstName) as 'Employee',
offices.country as 'Office'

FROM employees e1 INNER JOIN offices ON e1.officeCode = offices.officeCode 
WHERE NOT offices.country = 'USA';

-- #2 (2 rows): Products and product line where MSRP > $200
-- # Line, Product, Qty, MSRP, Price
SELECT 
productLine AS 'line', 
productName AS 'Product', 
quantityinStock as 'Qty',
MSRP as 'MSRP',
buyPrice as 'Price'
FROM products WHERE MSRP > 200;

-- #3 (435 rows): All orders shipped within 1 day ordered by customer name then ordered by product name
-- # customerName, orderNumber, orderDate, productName, quantityOrdered, o.shippedDate - o.orderDate
-- Use column alias to output orders that took longer than seven days to deliver
SELECT 
c.customerName, o.orderNumber, o.orderDate, p.productName, od.quantityOrdered, o.shippedDate - o.orderDate
FROM  orders o
	INNER JOIN customers c on o.customerNumber = c.customerNumber
	INNER JOIN orderdetails od ON o.orderNumber = od.orderNumber
	INNER JOIN products p on od.productCode = p.productCode
WHERE o.shippedDate - o.orderDate <= 1
ORDER BY c.customerName, p.productName;

-- #4 (1 row): Average, maximum, and minimum buyPrice of all products
-- # AvgPrice, MaxPrice, MinPrice
SELECT avg(buyPrice) as 'AvgPrice', max(buyPrice) as 'MaxPrice', min(buyPrice) as 'MinPrice'
FROM products;